import os
import pandas as pd
def update_servings_to_zero(csv_file):
    df = pd.read_csv(csv_file)
    df['servings'] = 0
    df.to_csv(csv_file, index=False)

def read_sleep_cals(csv_file , name):
    df = pd.read_csv(csv_file)
    sleep_value = df.loc[0, 'Sleep']
    calories_value = df.loc[0, 'Calories']
    df.at[0, 'Sleep'] = 0
    df.at[0, 'Calories'] = 0
    df.to_csv(csv_file, index=False)
    return add_to_daily(f'C:\\Users\\Hrishikesh U\\OneDrive\\Documents\\styling\\user_data_base\\{name}\\dailyprgoress.csv', sleep_value, calories_value)

def add_to_daily(csv_file , sleep , cals):
    df = pd.read_csv(csv_file)
    first_cell_last_row = df.iloc[-1, 0]
    print(first_cell_last_row)
    value = first_cell_last_row+1 
    new_row = {'Day':value, 'Sleep':sleep , 'Calories':cals}
    df = df._append(new_row ,ignore_index=True)
    df.to_csv(csv_file ,index = False)
    print("New row added successfully!")

def process_files_in_folder(folder_path , name ,parent ,current_calories):
    parent.curr_cals_comp.configure(text = f'0\{str(int(current_calories))} Calories')
    for file_name in os.listdir(folder_path):
        # print(file_name,type(file_name))
        # print(str(os.path.isfile(file_name)))
        file_path = os.path.join(folder_path , file_name)
        # print(file_path)
        if file_name.endswith('csv'):
    
            if file_name.startswith('foodinfo'):
                    update_servings_to_zero(file_path)
            elif file_name.startswith('tcl'):
                    read_sleep_cals(file_path , name=name)

            
        
# process_files_in_folder(r"C:\Users\Hrishikesh U\OneDrive\Desktop\change\Abdul")
    
