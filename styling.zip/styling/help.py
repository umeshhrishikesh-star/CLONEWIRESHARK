import tkinter as tk
import math
from customtkinter import CTkCanvas, CTkFrame

class CustomRoundSlider(CTkCanvas):
    def __init__(self, **kwargs):
        super.__init__()
        CTkCanvas.__init__(self, **kwargs)
        self.configure(bg='white', bd=0, highlightthickness=0)
        self.value = 0
        self.on_drag = False
        self.bind('<Button-1>', self.start_drag)
        self.bind('<B1-Motion>', self.drag)
        self.bind('<ButtonRelease-1>', self.stop_drag)
        self.draw_slider()

    def draw_slider(self):
        self.delete('slider')

        center_x, center_y = self.winfo_reqwidth() // 2, self.winfo_reqheight() // 2
        radius = min(center_x, center_y) - 10

        angle = math.radians(360 * self.value)

        x = center_x + int(radius * math.cos(angle))
        y = center_y - int(radius * math.sin(angle))

        self.create_oval(center_x - radius, center_y - radius, center_x + radius, center_y + radius, outline='black',
                          width=2, tags='slider')
        self.create_line(center_x, center_y, x, y, width=2, tags='slider')

    def set_value(self, x, y):
        center_x, center_y = self.winfo_reqwidth() // 2, self.winfo_reqheight() // 2
        angle = math.atan2(center_y - y, x - center_x)
        angle_deg = math.degrees(angle)
        self.value = (angle_deg + 360) % 360 / 360
        self.draw_slider()

    def start_drag(self, event):
        self.on_drag = True
        self.set_value(event.x, event.y)

    def drag(self, event):
        if self.on_drag:
            self.set_value(event.x, event.y)

    def stop_drag(self, event):
        self.on_drag = False

class CustomApp(CTkFrame):
    def __init__(self):
        CTkFrame.__init__(self)
        self.title('Custom Round Slider Example')
        self.geometry('300x300')

        self.slider = CustomRoundSlider(self, width=200, height=200)
        self.slider.pack(pady=20)

        self.label = tk.Label(self, text='Value:')
        self.label.pack()

        update_button = tk.Button(self, text='Update Value', command=self.update_value)
        update_button.pack()

    def update_value(self):
        self.label['text'] = f'Value: {self.slider.value:.2f}'

if __name__ == '__main__':
    app = CustomApp()
    app.mainloop()
