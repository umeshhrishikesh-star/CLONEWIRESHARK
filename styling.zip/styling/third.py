import tkinter as tk
import customtkinter as ctk
import csv
import new_food
import bodycomp
import workout_timer
import sleep
import change_to_next
import dail_progress_tree
import pandas as pd
class THIRDWINDOW(ctk.CTkToplevel):
    def __init__(self , parent , grandparent , greatparent,  name , gender , age , weight ,height , bmi , maintainance = 0):
        super().__init__(parent)
        self.name = name
        self.bmi = bmi
        
        print(greatparent.__class__.__name__)
        print(grandparent.__class__.__name__)
        print(parent.__class__.__name__)
        print('the end')
        self.greatparent = greatparent
        self.parent = parent
        self.grandparent = grandparent
        self.title("BMI Result") 
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        self.weight = weight
        x = (screen_width - 600) // 2 + 100
        y = (screen_height - 400) // 2 -70
        self.geometry(f"{600}x{400}+{x}+{y}")


        self.greeting = ctk.CTkLabel(self , text=f'Hello {self.name}' , font = ('consolas' , 20))
        self.greeting.place(relx = 0 , rely = 1 , anchor = 'sw')
        self.daily_button = ctk.CTkButton(self , text='View Daily Progress' , command=self.instance_daily_progress)
        self.daily_button.place(relx = 0 , rely = 0 , anchor = 'nw')

        self.proceed_next_day = ctk.CTkButton(self , text='Proceed to next Day' , command=lambda : change_to_next.process_files_in_folder(f'C:\\Users\\Hrishikesh U\\OneDrive\\Documents\\styling\\user_data_base\\{self.name}' , self.name))
        self.proceed_next_day.place(relx = 1 , rely = 1 , anchor = 'se')
        
        self.frame = interactframe(self , self.name ,weight ,height=height , bmi=bmi)
        self.frame.place(relx = 0.5 , rely = 0.5 , anchor = 'center' , relwidth = 0.8 , relheight = 0.8)

        df = pd.read_csv(f'C:\\Users\\Hrishikesh U\\OneDrive\\Documents\\styling\\user_data_base\\{name}\\tcl{name}.csv')
        # curr_cals = df.at[-1][0]['Calories']
        self.curr_cals= df.iloc[-1, 1]
        dp = pd.read_csv(f'user_information.csv')
        index = dp.index[dp.iloc[:, 0] == name].tolist()
        self.goal_cals = dp.iloc[index[0],6]
        # print(first_cell_last_row , index , goal_cals)
        self.curr_cals_comp = ctk.CTkLabel(self , text=f'{self.curr_cals}\{str(int(self.goal_cals))} Calories' , font = ('consolas' , 20) )
        self.curr_cals_comp.place(relx = 0.5 , rely = 0 , anchor = 'n')

        self.proceed_next_day = ctk.CTkButton(self , text='Proceed to next Day' , command=lambda : change_to_next.process_files_in_folder(f'C:\\Users\\Hrishikesh U\\OneDrive\\Documents\\styling\\user_data_base\\{self.name}' , self.name,self,self.goal_cals))
        self.proceed_next_day.place(relx = 1 , rely = 1 , anchor = 'se')
        
        
        self.parent.withdraw()
        self.protocol("WM_DELETE_WINDOW", self.on_second_window_close)
    def instance_daily_progress(self):
        a = dail_progress_tree.DailyWindow(self , f'C:\\Users\\Hrishikesh U\\OneDrive\\Documents\\styling\\user_data_base\\{self.name}\\dailyprgoress.csv')
    def on_second_window_close(self):
        # Destroy both windows when the new window is closed
        if self.parent.__class__.__name__ == self.grandparent.__class__.__name__:
            self.destroy()
            self.parent.deiconify()
            self.parent.destroy()
           
        else : 
            self.destroy()
            self.parent.deiconify()
            self.parent.destroy()
            self.grandparent.deiconify()
            self.grandparent.destroy()
            self.greatparent.deiconify()
            self.greatparent.destroy()
            
class interactframe(ctk.CTkFrame):
    
    def food_click(self ,parent):
       food = new_food.CalorieCounterApp(parent, self.parent.name , self.parent.goal_cals)
    
    def sleep_click(self , event) :
        a = sleep.sleep(self.name)
    def work_click(self):
        a = workout_timer.Workout_timer()
        


    def body_comp_click(self):
        a = bodycomp.body_comp(self.parent , self.parent.curr_cals, self.name ,self.weight , self.height , self.bmi)

    def __init__(self ,  parent ,name ,weight ,height , bmi):
        super().__init__(parent)
        self.name = name
        self.weight = weight
        self.height = height
        self.parent = parent
        self.bmi = bmi
        self.rowconfigure((0,1) , weight=2)
        self.columnconfigure((0,1) , weight=2)

        sleep_button = ctk.CTkButton(self , text = 'Sleep Cycle' , font = ('Helvetica' , 20) , command = lambda : self.sleep_click(parent))
        diet_button = ctk.CTkButton(self ,text='Food' , font = ('Helvetica' , 20) ,command=lambda: self.food_click(parent))
        workouts = ctk.CTkButton(self , text="Workouts" , font = ('Helvetica' , 20) , command=self.work_click)
        body_comp = ctk.CTkButton(self , text = "Update Weight" , font = ('Helvetica' , 20) , command=self.body_comp_click)

        sleep_button.grid(row = 0 , column= 0  ,padx = 10 , pady = 10, sticky = 'nsew')
        diet_button.grid(row = 0 , column = 1 ,padx = 10 , pady = 10 , sticky = 'nsew')
        workouts.grid(row = 1 , column = 0 ,padx = 10 , pady = 10 , sticky = 'nsew')
        body_comp.grid(row = 1 , column = 1 ,padx = 10 , pady = 10 , sticky = 'nsew')

# if __name__ == "__main__":
#     root = tk.Tk()
#     third_window = THIRDWINDOW(root, root, "John", "Male", 25, 70, 180, 2000, 23)
#     root.mainloop()
