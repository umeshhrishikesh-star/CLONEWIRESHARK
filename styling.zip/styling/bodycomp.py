import customtkinter as ctk
import ttkbootstrap as ttk
import csv
import pandas as pd

class body_comp(ctk.CTkToplevel):

    def __init__(self ,parent,current, name, weight , height , bmi):
        super().__init__()
        self.resizable(False , False)
        self.weight = weight
        self.name = name
        self.bmi = bmi
        self.current = current
        self.grab_set()
        self.parent = parent
        self.title("Update Weight")
        self.height = float(height)
        # self.grab_set()
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        weight = self.weight
        x = (screen_width - 400) // 2
        y = (screen_height - 300) // 2
        self.geometry(f"{400}x{300}+{x}+{y}")
        
        update_frame = ctk.CTkFrame(self)
        update_frame.pack(expand = True , fill = 'both')
        update_frame.rowconfigure((0,1) , weight=1)
        update_frame.columnconfigure((0,1,2) , weight=1)

        self.bmi_label = ctk.CTkLabel(update_frame , text="BMI" , font = ('consolas' , 100))
        self.bmi_label.grid(row = 0 , column = 0 , columnspan = 3)


        self.weight_var = float(self.weight)
        self.bmi_var = self.bmi

        self.weight_label = ctk.CTkLabel(update_frame , text=f'{self.weight_var}kg' , font=('consolas' ,20))
        self.weight_label.grid(row = 1, column = 1)
        

        add_button = ctk.CTkButton(update_frame , text='+' , font = ('consolas' , 30) ,command=self.add_click)
        add_button.grid(row = 1 , column =0)

        sub_button = ctk.CTkButton(update_frame , text='-' , font = ('consolas' , 30) ,command=self.sub_click)
        sub_button.grid(row = 1 , column =2)



        self.protocol("WM_DELETE_WINDOW", self.update_bmi)

    def add_click(self):
        self.weight_var = self.weight_var+0.5
        print(round((self.weight_var/(self.height)**2)*10000 , 1))
        self.bmi_var = round((self.weight_var/(self.height)**2)*10000 , 1)
        self.bmi_label.configure(text = f'{round((self.weight_var/(self.height)**2)*10000 , 1)}')
        self.weight_label.configure(text = f'{self.weight_var}kg')
    def sub_click(self):

        self.weight_var = self.weight_var-0.5
        self.bmi_label.configure(text = f'{round((self.weight_var/(self.height)**2)*10000 , 1)}')

        self.bmi_var = round((self.weight_var/(self.height)**2)*10000 , 1)

        self.weight_label.configure(text = f'{self.weight_var}kg')
    def update_bmi(self):
        
        print(self.weight_var)
        count = -1
        with open(r'user_information.csv' ,'r') as f1:
            reader = csv.reader(f1)
            for i in reader :
                if i:
                    count+=1
                    if i[0] == self.name:
                        break
            print(count)
        with open(r'user_information.csv' ,'r') as f1:

            
            
            row = csv.reader(f1)
            reader = list(row)
            
            print(reader[count][3])
            reader[count][3] = self.weight_var
            reader[count][5] = self.bmi_var
            print(reader[count][3])

            with open(r'user_information.csv', 'w' ,newline='') as f:
                writer = csv.writer(f)
                writer.writerows(reader)
        
        df = pd.read_csv('user_information.csv')
        index = df.index[df.iloc[:, 0] == self.name].tolist()
        age = df.iloc[index[0],2]
        height = df.iloc[index[0],4]
        goal = df.iloc[index[0],7]
        gender = df.iloc[index[0] , 1]
        activity = df.iloc[index[0] , 8]
        self.destroy()
        print(int(self.weight_var))
        print('age',int(age))
        print('height',int(height))
        print('goal',goal)
        print('gender',gender)
        print('activity',int(activity))
        if str(gender) == 'Male':
            maintainance = round((88.362 + (13.397 *int(self.weight_var)) + (4.799 * int(height)) - (5.677 * int(age))) * float(activity), -2)
        else :
            maintainance = round((447.593 + (9.274 * int(self.weight_var)) + (3.098 * height) - (4.330 * age)) * 1.2, -2)
        print(maintainance ,type(maintainance))
        # print(maintainance)   
        if str(goal) == 'Gain':
            maintainance+=300
        elif str(goal) == 'Loose':
            maintainance-=300
        else:
            maintainance = maintainance
        print(maintainance)
        # self.parent.curr_cals_comp.configure(text = f'{self.current}\{int(maintainance)} Calories')
        df.iloc[index, df.columns.get_loc('maintainance')] = maintainance
        df.to_csv('user_information.csv', index=False)      
