self.signup_label.bind("<Enter>", lambda event: self.signup_label.configure(cursor="hand2"))
        self.signup_label.bind("<Leave>", lambda event: self.signup_label.configure(cursor=""))
        self.signup_label.bind("<Button-1>", lambda event: self.open_link())
        