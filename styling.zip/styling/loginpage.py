import tkinter as tk
from CTkMessagebox import CTkMessagebox
import customtkinter as ctk
import csv
import signuppage
import third

class LoginWindow(ctk.CTk):
    def __init__(self):
        super().__init__()
        # Styling the first window
        self._set_appearance_mode('dark')
        self.title("User Information") 
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        self.resizable(False , False)
        x = (screen_width - 600) // 2 + 100
        y = (screen_height - 400) // 2 -70

        self.geometry(f"{600}x{400}+{x}+{y}")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        # Calling frame
        self.login_frame = LoginFrame(self)
        self.login_frame.place(relx=0.5, rely=0.5, anchor='center')

        # User signup
        self.s_label = ctk.CTkLabel(self, text="Not a member:    ", font=('consolas', 20))
        self.signup_label = ctk.CTkLabel(self, text="SignUp", font=('consolas', 20), text_color='#0645AD')

        self.s_label.place(relx=0.48, rely=0.8, anchor='center')
        self.signup_label.place(relx=0.63, rely=0.8, anchor='center')

        self.signup_label.bind("<Enter>", lambda event: self.signup_label.configure(cursor="hand2"))
        self.signup_label.bind("<Leave>", lambda event: self.signup_label.configure(cursor=""))
        self.signup_label.bind("<Button-1>", lambda event: self.open_link())
        

    def open_link(self):
        sign_page = signuppage.FirstWindow(self)

    def on_click(self, child):
        name = child.name_entry.get()
        password = child.password_entry.get()
        is_user = False
        user = []
        with open('user_information.csv', 'r') as info:
            reader = csv.reader(info)
            for line in reader:
                if line:
                    if line[0] == name:
                        is_user = True
                        user = line
                        break
        if is_user:
            login_third_instance = third.THIRDWINDOW(self, self, self, user[0], user[1], user[2], user[3], user[4], user[5], user[6])
        else:
            CTkMessagebox(title='Error', message='USER NOT PRESENT', icon='cancel')

class LoginFrame(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent)
        # Frame widgets initialization
        self.rowconfigure((0, 1, 2), weight=1)
        self.columnconfigure((0, 1), weight=1)

        self.name_label = ctk.CTkLabel(self, text="Name", font=('consolas', 20))
        self.password_label = ctk.CTkLabel(self, text="Password", font=('consolas', 20))
        self.name_entry = ctk.CTkEntry(self)
        self.password_entry = ctk.CTkEntry(self, show='*')

        self.name_label.grid(row=0, column=0, padx=10, pady=10, sticky='nsew')
        self.password_label.grid(row=1, column=0, padx=10, pady=10, sticky='nsew')
        self.name_entry.grid(row=0, column=1, padx=10, pady=10, sticky='nsew')
        self.password_entry.grid(row=1, column=1, padx=10, pady=10, sticky='nsew')

        self.login_button = ctk.CTkButton(self, text='LOGIN', command=lambda: parent.on_click(self), font=('consolas', 20))
        self.login_button.grid(row=2, column=0, columnspan=2, padx=10, pady=10, sticky='nsew')

if __name__ == "__main__":
    a = LoginWindow()
    a.mainloop()