import pandas as pd
import tkinter as tk
import customtkinter as ctk
import csv
import third

class SecondWindow(ctk.CTkToplevel):
    
    def choice(self, name , gender ,age , weight , height , maintainance , bmi ,Goal ):
        df = pd.read_csv('user_information.csv')
        print(maintainance)
        df.at[df.index[-1], 'maintainance'] = maintainance
        df.at[df.index[-1], 'goal'] = Goal
        # print(df.loc[a , 'maintainance'])
        df.to_csv('user_information.csv' , index=False)        

        third_window_instance = third.THIRDWINDOW(self, self.parent ,self.grandparent , name , gender ,age , weight , height  ,maintainance , bmi)
    
    
    def __init__(self, parent ,grandparent , name , gender , age , weight , height , maintainance , bmi):
        super().__init__(parent)
        print(parent.__class__.__name__)
        print(grandparent.__class__.__name__)
        print('the end')
        self.grandparent = grandparent
        self.parent = parent
        
        self.parent.withdraw()
        self.title("BMI Result") 
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()

        x = (screen_width - 600) // 2 + 100
        y = (screen_height - 400) // 2 -70
        self.geometry(f"{600}x{400}+{x}+{y}")
        
        self.resizable(False, False)
        
        fit_goal = ''
        if 18.5>bmi:
            fit_goal = 'Gain Weight'
        elif 18.5<= bmi <=25:
            fit_goal = 'MaintainWeight' 
        elif 25< bmi < 30 :
             fit_goal = 'LooseWeight'
        else:
             fit_goal = 'LooseWeight'

        label_reco = ctk.CTkLabel(master=self , text='RECOMMENDED : '+fit_goal ,font=('consolas' , 16) )     
        label_reco.place(relx = 0.5 , rely = 0.2 ,anchor = 'center')
        label_maintaince = ctk.CTkLabel(master=self , text=f'Calculated Maintainance Calories : {int(maintainance)} \n(the amount of food that you need to maintain your body weight)',font=('consolas' , 16))
        label_maintaince.place(relx = 0.5 , rely = 0.4 , anchor = 'center')

        choice_frame = ctk.CTkFrame(self)
        choice_frame.rowconfigure((0,1,2) , weight=1)
        choice_frame.columnconfigure((0,1,2) ,weight=1)
        
        #label for choice
        loose_label = ctk.CTkLabel(choice_frame , text='LOOSE WEIGHT' ,font=('consolas' , 16) )
        loose_desc = ctk.CTkLabel(choice_frame , text=f'You would have to consume \n{int(maintainance) - 300} calories' , font=('consolas' , 13))
        loose_button = ctk.CTkButton(choice_frame , text='Loose Weight' , command=lambda : self.choice( name , gender , age , weight , height , int(maintainance)-300 , bmi,'Loose') , font=('consolas' , 13))

        maintain_label = ctk.CTkLabel(choice_frame , text='MAINTAIN WEIGHT',font=('consolas' , 16))
        maintain_desc = ctk.CTkLabel(choice_frame , text=f'You would have to consume \n{int(maintainance)} calories',font=('consolas' , 13))
        maintain_button = ctk.CTkButton(choice_frame , text='MAINTAIN Weight' ,command=lambda : self.choice( name , gender , age , weight , height , int(maintainance) , bmi,'Maintain'),font=('consolas' , 13)) 

        gain_label = ctk.CTkLabel(choice_frame , text='GAIN WEIGHT',font=('consolas' , 16))
        gain_desc = ctk.CTkLabel(choice_frame , text=f'You would have to consume \n{int(maintainance) + 300} calories',font=('consolas' , 13))
        gain_button = ctk.CTkButton(choice_frame , text='GAIN Weight' , command=lambda : self.choice( name , gender , age , weight , height , int(maintainance)+300 , bmi , 'Gain'),font=('consolas' , 13))

        

        #gridding
        loose_label.grid(row = 0 , padx = 10  , column = 0)
        loose_desc.grid(row = 1 , padx = 10 , pady = 10 , column = 0)
        loose_button.grid(row = 2 , padx = 10  , column = 0)

        maintain_label.grid(row = 0 , padx = 10  , column = 1)
        maintain_desc.grid(row = 1 , padx = 10 , pady = 10 , column = 1)
        maintain_button.grid(row = 2 , padx = 10  , column = 1)

        gain_label.grid(row = 0 , padx = 10  , column = 2)
        gain_desc.grid(row = 1 , padx = 10 , pady = 10 , column = 2)
        gain_button.grid(row = 2 , padx = 10  , column = 2)

        choice_frame.place(relx = 0.5 , rely = 0.7 , anchor = 'center')
        
        self.protocol("WM_DELETE_WINDOW", self.on_second_window_close)


        

    def on_second_window_close(self):
        # Destroy both windows when the new window is closed
        self.destroy()
        self.parent.deiconify()
        self.parent.destroy() 
        self.grandparent.deiconify()
        self.grandparent.destroy()

