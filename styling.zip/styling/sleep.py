import customtkinter as ctk
import pandas as pd
class sleep(ctk.CTkToplevel):

    def __init__(self ,name):
        super().__init__()
        self.name = name
        self.resizable(False , False)
        self.title("Update Weight")
        self.grab_set()
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        x = (screen_width - 400) // 2
        y = (screen_height - 300) // 2
        self.geometry(f"{400}x{300}+{x}+{y}")

        
        update_frame = ctk.CTkFrame(self)
        update_frame.pack(expand = True , fill = 'both')
        update_frame.rowconfigure((0,1) , weight=1)
        update_frame.columnconfigure((0,1,2) , weight=1)

        self.sleep_var = 0

        self.sleep_label = ctk.CTkLabel(update_frame , text="SLEEP" , font = ('consolas' , 100))
        self.sleep_label.grid(row = 0 , column = 0 , columnspan = 3)

        
        self.sleep_hour_label = ctk.CTkLabel(update_frame , text=f'hours' , font=('consolas' ,20))
        self.sleep_hour_label.grid(row = 1, column = 1)
        

        add_button = ctk.CTkButton(update_frame , text='+' , font = ('consolas' , 30) ,command=self.add_click)
        add_button.grid(row = 1 , column =0)

        sub_button = ctk.CTkButton(update_frame , text='-' , font = ('consolas' , 30) ,command=self.sub_click)
        sub_button.grid(row = 1 , column =2)
        self.protocol("WM_DELETE_WINDOW", self.on_close)
    def on_close(self):
        file_cal_sleep = f"C:\\Users\\Hrishikesh U\\OneDrive\\Documents\\styling\\user_data_base\\{self.name}\\tcl{self.name}.csv"
        df = pd.read_csv(file_cal_sleep)
        df.at[0,'Sleep'] = int(self.sleep_var)
        df.to_csv(file_cal_sleep , index=False)
        print(self.sleep_var)
        self.destroy()


    def add_click(self):
        if self.sleep_var<12:
            self.sleep_var = self.sleep_var+1
            self.sleep_label.configure(text = f'{self.sleep_var}')

    def sub_click(self):
        if self.sleep_var>0:
            self.sleep_var = self.sleep_var-1
            self.sleep_label.configure(text = f'{self.sleep_var}')

# a = sleep()
# a.mainloop()