import tkinter as tk
from CTkMessagebox import CTkMessagebox
import customtkinter as ctk
import csv
import os
import second
import third

class FirstWindow(ctk.CTkToplevel):

    def check_valid(self, name, age, weight, height):
        print(name , age , weight , height)
        if name and age and weight and height and not name.isdigit() and age.isdigit() and weight.isdigit() and height.isdigit():
            if 15 < int(age) < 90 and 100 < int(height) < 220:
                return True
            else:
                CTkMessagebox(title="Error", message="Something went wrong!!!", icon="cancel")
                return False
        else:
            CTkMessagebox(title="Error", message="Something went wrong!!!", icon="cancel")
            return False

    def update_bio(self, name, gender, age, weight, height, bmi, maintainance):
        is_present = False
        with open('user_information.csv', 'r', newline='') as rfile:
            reader = csv.reader(rfile, delimiter=',')

            for line in reader:
                if line:
                    if line[0] == name:
                        is_present = True
                        break

        if is_present:
            CTkMessagebox(title="Error", message="User already Present", icon="cancel")

        if not is_present:
            with open('user_information.csv', 'a', newline='') as wfile:
                writer = csv.writer(wfile)
                writer.writerow([name, gender, age, weight, height, bmi, maintainance , 'Maintain' , self.activity])
            folder_path = f"C:\\Users\\Hrishikesh U\\OneDrive\\Documents\styling\\user_data_base\\{name}"
            os.makedirs(folder_path, exist_ok=True)

            with open(f'C:\\Users\\Hrishikesh U\\OneDrive\\Documents\\styling\\user_data_base\\{name}\\foodinfo{name}.csv', 'w', newline='') as f4:
                writer1 = csv.writer(f4)
                with open('foodinfo.csv', 'r', newline='') as f3:
                    reader = csv.reader(f3)

                    for i in reader:
                        writer1.writerow(i)
            with open(f"C:\\Users\\Hrishikesh U\\OneDrive\\Documents\\styling\\user_data_base\\{name}\\tcl{name}.txt", 'w') as f2:
                f2.write('0')
            with open(f'C:\\Users\\Hrishikesh U\\OneDrive\\Documents\\styling\\user_data_base\\{name}\\tcl{name}.csv' , 'w' , newline='') as cals_sleep:
                writer = csv.writer(cals_sleep)
                writer.writerow(['Sleep' , 'Calories'])
                writer.writerow([0,0])
            with open (f'C:\\Users\\Hrishikesh U\\OneDrive\\Documents\\styling\\user_data_base\\{name}\\dailyprgoress.csv' , 'w' ,newline='') as daily_track:
                writer = csv.writer(daily_track)
                writer.writerow(['Day','Sleep' , 'Calories'])
                writer.writerow([0,0,0])

        return is_present

    def maintainancecalc(self, gender, activity, weight, height, age):
        if gender == 'Male':
            if 'Sedentary' in activity:
                maintainance = round((88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age)) * 1.2, -2)
                self.activity = 1.2
            elif 'Moderately' in activity:
                maintainance = round((88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age)) * 1.55, -2)
                self.activity = 1.55
            else:
                self.activity = 1.9
                maintainance = round((88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age)) * 1.9, -2)
        elif gender == 'Female':
            if 'Sedentary' in activity:
                self.activity = 1.2
                maintainance = round((447.593 + (9.274 * weight) + (3.098 * height) - (4.330 * age)) * 1.2, -2)
            elif 'Moderately' in activity:
                self.activity = 1.55
                maintainance = round((447.593 + (9.274 * weight) + (3.098 * height) - (4.330 * age)) * 1.55, -2)
            else:
                self.activity = 1.9
                maintainance = round((447.593 + (9.274 * weight) + (3.098 * height) - (4.330 * age)) * 1.9, -2)
        return maintainance

    def onclick(self, child):
        name = child.name_entry.get()
        gender = child.gender_combo.get()
        age = child.age_entry.get()
        weight = child.weight_entry.get()
        height = child.height_entry.get()
        activity = child.activity_combo.get()

        if self.check_valid(name, age, weight, height):
            bmi = (int(weight) / int(height) ** 2) * 10000
            maintainance = self.maintainancecalc(gender, activity, int(weight), int(height), int(age))
            determine_window = self.update_bio(name, gender, age, weight, height, bmi, maintainance)
            if not determine_window:
                second_window = second.SecondWindow(self, self.parent, name, gender, age, weight, height, maintainance, bmi)

    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.parent.withdraw()
        self.title("User Information")
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        self.resizable(False , False)
        x = (screen_width - 600) // 2 + 100
        y = (screen_height - 400) // 2 - 70

        self.geometry(f"{600}x{400}+{x}+{y}")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        self.main_frame = MAIN_FRAME(self)
        self.main_frame.grid(padx=20, pady=20)
        self.protocol("WM_DELETE_WINDOW", self.on_second_window_close)

    def on_second_window_close(self):
        self.destroy()
        self.parent.deiconify()
        self.parent.destroy()


class MAIN_FRAME(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent)
        self.rowconfigure((0, 1, 2, 3, 4, 5, 6), weight=1)
        self.columnconfigure((0, 1), weight=1)
        

        self.name_label = ctk.CTkLabel(self, text="Name ", fg_color="#c4124a", text_color='white', justify=ctk.CENTER,
                                       corner_radius=9, font=("consolas", 20))
        self.gender_label = ctk.CTkLabel(self, text="Gender ", fg_color="#c4124a", text_color='white',
                                         justify=ctk.CENTER, corner_radius=9, font=("consolas", 20))
        self.age_label = ctk.CTkLabel(self, text="Age (years) ", fg_color="#c4124a", text_color='white',
                                      justify=ctk.CENTER, corner_radius=9, font=("consolas", 20))
        self.weight_label = ctk.CTkLabel(self, text="Weight (kg) ", fg_color="#c4124a", text_color='white',
                                         justify=ctk.CENTER, corner_radius=9, font=("consolas", 20))
        self.height_label = ctk.CTkLabel(self, text="Height (cm) ", fg_color="#c4124a", text_color='white',
                                         justify=ctk.CENTER, corner_radius=9, font=("consolas", 20))
        self.activity_label = ctk.CTkLabel(self, text="Activity Level ", fg_color="#c4124a", text_color='white',
                                           justify=ctk.CENTER, corner_radius=9, font=("consolas", 20))

        self.name_entry = ctk.CTkEntry(self, font=("consolas", 20))
        self.gender_combo = ctk.CTkComboBox(self, values=["Male", "Female"], font=("consolas", 20))
        self.age_entry = ctk.CTkEntry(self, font=("consolas", 20))
        self.weight_entry = ctk.CTkEntry(self, font=("consolas", 20))
        self.height_entry = ctk.CTkEntry(self, font=("consolas", 20))
        self.activity_combo = ctk.CTkComboBox(self,
                                              values=['Sedentary(Never or rarely include physical activity in your day)',
                                                      'Moderately Active(Include at least 30 minutes of moderate activity most days of the week)',
                                                      'Very Active ( Include large amounts of moderate or vigorous activity in your day)'],
                                              font=("consolas", 20))

        self.name_label.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        self.gender_label.grid(row=1, column=0, padx=10, pady=10, sticky="nsew")
        self.age_label.grid(row=2, column=0, padx=10, pady=10, sticky="nsew")
        self.weight_label.grid(row=3, column=0, padx=10, pady=10, sticky="nsew")
        self.height_label.grid(row=4, column=0, padx=10, pady=10, sticky="nsew")
        self.activity_label.grid(row=5, column=0, padx=10, pady=10, sticky="nsew")

        self.name_entry.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")
        self.gender_combo.grid(row=1, column=1, padx=10, pady=10, sticky="nsew")
        self.age_entry.grid(row=2, column=1, padx=10, pady=10, sticky="nsew")
        self.weight_entry.grid(row=3, column=1, padx=10, pady=10, sticky="nsew")
        self.height_entry.grid(row=4, column=1, padx=10, pady=10, sticky="nsew")
        self.activity_combo.grid(row=5, column=1, padx=10, pady=10, sticky="nsew")

        self.submit_button = ctk.CTkButton(self, text="Submit", command=lambda: parent.onclick(self),
                                           font=("consolas", 20))
        self.submit_button.grid(row=6, column=0, columnspan=2, padx=10, pady=10, sticky="nsew")

# if __name__ == "__main__":
#     a = FirstWindow()
#     a.mainloop()
