import customtkinter as ctk
from PIL import Image, ImageTk

class Workout_timer(ctk.CTkToplevel):
    def __init__(self):
        super().__init__()
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        self.resizable(False , False)
        x = (screen_width - 600) // 2 + 100
        y = (screen_height - 400) // 2 - 70

        self.grab_set()

        
        self.geometry(f"{600}x{400}+{x}+{y}")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        
        self.rowconfigure((0,1,2,3,4) ,weight=1)
        self.columnconfigure((0,1,2) ,weight=1)

        self.pushup = ctk.CTkLabel(self , text='Pushups' ,font=('consolas' ,50))
        self.pushup.grid(row = 0 , column = 1 ,sticky = 'w' , pady = 10)

        self.pushup.bind("<Enter>", lambda event: self.pushup.configure(cursor="hand2"))
        self.pushup.bind("<Leave>", lambda event: self.pushup.configure(cursor=""))
        self.pushup.bind('<Button-1>' ,lambda event : self.click_work())
        
        self.pullups = ctk.CTkLabel(self , text='Pullups',font=('consolas' ,50))
        self.pullups.grid(row = 1 , column = 1,sticky = 'w' , pady = 10)

        
        self.pullups.bind("<Enter>", lambda event: self.pullups.configure(cursor="hand2"))
        self.pullups.bind("<Leave>", lambda event: self.pullups.configure(cursor=""))
        self.pullups.bind('<Button-1>' ,lambda event : self.click_work())
        


        self.squats = ctk.CTkLabel(self , text='Squats',font=('consolas' ,50))
        self.squats.grid(row = 2 , column = 1,sticky = 'w')

        
        self.squats.bind("<Enter>", lambda event: self.squats.configure(cursor="hand2"))
        self.squats.bind("<Leave>", lambda event: self.squats.configure(cursor=""))
        self.squats.bind('<Button-1>' ,lambda event : self.click_work())
        

        self.planks = ctk.CTkLabel(self, text='Planks',font=('consolas' ,50))
        self.planks.grid(row = 3 , column = 1,sticky = 'w')
        
        
        self.planks.bind("<Enter>", lambda event: self.planks.configure(cursor="hand2"))
        self.planks.bind("<Leave>", lambda event: self.planks.configure(cursor=""))
        self.planks.bind('<Button-1>' ,lambda event : self.click_work())
        


        self.running = ctk.CTkLabel(self , text="Running",font=('consolas' ,50))
        self.running.grid(row = 4 , column = 1,sticky = 'w')

        
        self.running.bind("<Enter>", lambda event: self.running.configure(cursor="hand2"))
        self.running.bind("<Leave>", lambda event: self.running.configure(cursor=""))
        self.running.bind('<Button-1>' ,lambda event : self.click_work())
        

        self.pushup_img = ctk.CTkImage(Image.open('pushup.jpg'), size=(65, 65))
        self.pushupimg_label = ctk.CTkLabel(self , text='' , image=self.pushup_img)
        self.pushupimg_label.grid(row = 0 , column = 0 ,sticky = 'nsew')

        self.pullups_img = ctk.CTkImage(Image.open('pull up.jpeg'), size=(65, 65))
        self.pullupsimg_label = ctk.CTkLabel(self , text='' , image=self.pullups_img)
        self.pullupsimg_label.grid(row = 1 , column = 0 ,sticky = 'nsew')
        
        self.squats_img = ctk.CTkImage(Image.open('squats.webp'), size=(65, 65))
        self.squatsimg_label = ctk.CTkLabel(self , text='' , image=self.squats_img)
        self.squatsimg_label.grid(row = 2 , column = 0 ,sticky = 'nsew')

        self.plank_img = ctk.CTkImage(Image.open('planks.jpeg'), size=(65, 65))
        self.plankimg_label = ctk.CTkLabel(self , text='' , image=self.plank_img)
        self.plankimg_label.grid(row = 3 , column = 0 ,sticky = 'nsew')

        self.running_img = ctk.CTkImage(Image.open('run.webp'), size=(65, 65))
        self.runningimg_label = ctk.CTkLabel(self , text='' , image=self.running_img)
        self.runningimg_label.grid(row = 4 , column = 0 ,sticky = 'nsew')
        
        time_frame = ctk.CTkFrame(self)
        self.user_slider = ctk.CTkSlider(time_frame, from_=0 , to=120  ,orientation="horizontal", command=self.slider_value)
        self.user_slider.pack()
        
        self.timer_label = ctk.CTkLabel(time_frame , text=0)
        self.timer_label.pack()
        timer_button = ctk.CTkButton(time_frame, text='Timer', command=self.timer_window)
        timer_button.pack()
        time_frame.grid(row = 4 , column =2)

       

    def slider_value(self ,event):
        print(int(self.user_slider.get()))
        self.timer_label.configure(text = str(int(self.user_slider.get())))
        
        
    def timer_window(self):
        self.a = ctk.CTkToplevel()
        self.a.grab_set()
        self.a.geometry('400x300')
        self.win_time = ctk.CTkLabel(self.a, text='Time' ,font = ('consolas' ,130))
        self.a.protocol("WM_DELETE_WINDOW", self.do_nothing)
        self.win_time.pack()
        self.time_var = int(self.user_slider.get())
        self.click_button = ctk.CTkButton(self.a, text='Start', command=lambda : self.onclick(self.time_var) ,font=('consolas' ,50) ,width = 300 , height=50 )
        self.click_button.pack()

        
    def do_nothing(self):
        pass
    def click_work(self):
        print('stating to workout')
        self.timer_window()
   
    def onclick(self, count=20):
        
        
        if count > 0:
            try:
                self.win_time.configure(text=f'{count}s')
                self.click_button.configure(state = 'disabled')
            except:
                print('',end="")
            
            self.after(1000, lambda: self.onclick(count - 1))  # Schedule the next update after 1000 milliseconds (1 second)
            
        else:
            if self.win_time.winfo_exists():
                self.win_time.configure(text='Time is up!' ,font = ('consolas' , 50 ))
                self.a.destroy()
# a = Workout_timer()
# a.mainloop()