import tkinter as tk
import customtkinter as ctk
import csv
from PIL import Image, ImageTk
import pandas as pd
from CTkMessagebox import CTkMessagebox
# name = 'abdul'
# target = input()
class CalorieCounterApp(ctk.CTkToplevel):
    def __init__(self , parent, name , target):
        print(name)
        super().__init__(parent)
        self.parent = parent
        self.title("Calorie Counter")
        self.name = name
        self.target = target
        
        #Iniialize functional data
        self.food_data = self.load_food_data()
        self.food_widgets = {}
        self.food_frame = None
        self.total_calories = self.load_previousTcal()

        #Initialize ExitEntry Routine
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.grab_set()
        self.create_widgets()
 
    def on_close(self):
        # file_cal = f"C:\\Users\\Hrishikesh U\\OneDrive\\Documents\\styling\\user_data_base\\{self.name}\\tcl{self.name}.txt"
        file_cal_sleep = f"C:\\Users\\Hrishikesh U\\OneDrive\\Documents\\styling\\user_data_base\\{self.name}\\tcl{self.name}.csv"

        # with open(file_cal , 'w') as file:
        #     file.write(str(self.total_calories))
        
        self.parent.curr_cals_comp.configure(text = f'{self.total_calories}\{str(int(self.target))} Calories')
        df = pd.read_csv(file_cal_sleep)
        df.at[0,'Calories'] = int(self.total_calories)
        df.to_csv(file_cal_sleep , index=False)
        self.destroy()

    def load_previousTcal(self):
        # file_cal = f"C:\\Users\\Hrishikesh U\\OneDrive\\Documents\\styling\\user_data_base\\{self.name}\\tcl{self.name}.txt"
        file_cal_sleep = f"C:\\Users\\Hrishikesh U\\OneDrive\\Documents\\styling\\user_data_base\\{self.name}\\tcl{self.name}.csv"

        # ptcal = ""

        # with open(file_cal , 'r') as file :
        #     ptcal = file.read().strip()
        try:
            df = pd.read_csv(file_cal_sleep)
            cal_value = df.loc[0,'Calories']
            print(cal_value , type(cal_value))
        except Exception as e:
            print('error' , type(cal_value))
        
            
        return str(cal_value)    
    def load_food_data(self):
        food_data = {}
        self.foodname = f'C:\\Users\\Hrishikesh U\\OneDrive\\Documents\\styling\\user_data_base\\{self.name}\\foodinfo{self.name}.csv'
        with open(self.foodname, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                food_data[row['food']] = [int(row['cps']), int(row['servings'])]
        return food_data

    def create_widgets(self):
        
        self.food_frame = ctk.CTkFrame(self)
        self.food_frame.grid(row=0, column=0, columnspan=6)
        self.ptcal = self.load_previousTcal()
        for i, (food, calories_servings) in enumerate(self.food_data.items()):
            self.add_food_widget(food_frame=self.food_frame, food=food, calories=calories_servings[0], servings=int(calories_servings[1]))

        add_food_button = ctk.CTkButton(self, text="Add Food", command=self.add_food_window ,font=('Calibri' , 20))
        add_food_button.grid(row=1, column=0, columnspan=6, pady=10)

        self.total_calories_label = ctk.CTkLabel(self, text=f'Total Calories: {self.ptcal}' ,font=('Calibri' , 20))
        self.total_calories_label.grid(row=2, column=0, columnspan=6, pady=10)

    def add_food_widget(self, food_frame, food, calories, servings):
        identifier = len(self.food_widgets)
        # Food label
        food_label = ctk.CTkLabel(food_frame, text=food ,font=('Calibri' , 20))
        food_label.grid(row=identifier, column=0, padx=10, pady=5, sticky='w')

        # Calories label
        calorie_label = ctk.CTkLabel(food_frame, text=f'Calories per serving: {calories}',font=('Calibri' , 20))
        calorie_label.grid(row=identifier, column=1, padx=10, pady=5, sticky='w')

        # Servings label
        servings_label = ctk.CTkLabel(food_frame, text='Number of servings:',font=('Calibri' , 20))
        servings_label.grid(row=identifier, column=2, padx=10, pady=5, sticky='e')

        # Label to display the number of servings
        serving_value = ctk.CTkLabel(food_frame, text=f'{servings}',font=('Calibri' , 20))
        serving_value.grid(row=identifier, column=3, padx=5, pady=5)

        # Buttons for adjusting servings
        plus_button = ctk.CTkButton(food_frame, text='+', command=lambda idx=identifier: self.adjust_servings(idx, 1) ,width=50,height=30)
        plus_button.grid(row=identifier, column=4, padx=5, pady=5)

        minus_button = ctk.CTkButton(food_frame, text='-', command=lambda idx=identifier: self.adjust_servings(idx, -1) ,width=50,height=30)
        minus_button.grid(row=identifier, column=5, padx=5, pady=5)

        delete = ctk.CTkImage(Image.open('bin.png'), size=(26, 26))
        bin_button = ctk.CTkButton(food_frame, text='', image=delete, command=lambda idx=identifier: self.delete_food_row(idx) ,width=50 ,height=30)
        bin_button.image = delete
        bin_button.grid(row=identifier, column=6, padx=5, pady=5)

        self.food_widgets[identifier] = {
            'food_label': food_label,
            'calorie_label': calorie_label,
            'servings_label': servings_label,
            'serving_value': serving_value,
            'plus_button': plus_button,
            'minus_button': minus_button,
            'delete_button': bin_button
        }

    def add_food_window(self):
        new_window = ctk.CTkToplevel(self)
        new_window.title("Add Food")
        new_window.grab_set()

        # Entry fields for new food and calories per serving
        food_entry = ctk.CTkEntry(new_window, placeholder_text='Enter Food Name' , font=('consolas' , 20) ,width = 200)
        food_entry.pack(padx=10, pady=10)
        calories_entry = ctk.CTkEntry(new_window, placeholder_text='Enter Cals per serving' ,font=('consolas' , 20) , width = 200)
        calories_entry.pack(padx=10, pady=10)

        # Submit button
        submit_button = ctk.CTkButton(new_window, text="Submit", command=lambda: self.add_new_food(food_entry, calories_entry, new_window),font=('consolas' , 20))
        submit_button.pack(padx=10, pady=10)

    def add_new_food(self, food_entry, calories_entry, new_window):
        new_food = food_entry.get()
        new_calories = calories_entry.get()

        if new_food and new_calories.isdigit():
            new_calories = int(new_calories)
            self.food_data[new_food] = [new_calories, 0]  # Change to a list
            self.add_food_widget(food_frame=self.food_frame, food=new_food, calories=new_calories, servings=0)
            
            # Update CSV file
            with open(self.foodname, 'a', newline='') as f1:
                writer = csv.writer(f1)
                writer.writerow([new_food, new_calories, 0])  # Change 0 to the initial servings value
                new_window.destroy()
        else :
           CTkMessagebox(master=self , title="Warning Message!", message="Enter Proper calories!",
                  icon="warning")  

        
    def delete_food_row(self, identifier):
            if identifier in self.food_widgets:
                
                food_name = self.food_widgets[identifier]['food_label'].cget("text")

                
                if food_name in self.food_data:
                    del self.food_data[food_name]

                
                deleted_food_widgets = self.food_widgets.pop(identifier, None)

                if deleted_food_widgets:
                    # Delete corresponding widgets
                    deleted_food_widgets['food_label'].destroy()
                    deleted_food_widgets['calorie_label'].destroy()
                    deleted_food_widgets['servings_label'].destroy()
                    deleted_food_widgets['serving_value'].destroy()
                    deleted_food_widgets['plus_button'].destroy()
                    deleted_food_widgets['minus_button'].destroy()
                    deleted_food_widgets['delete_button'].destroy()

                    # Update total calories
                    self.update_total_calories()

                    # Update CSV file
                    with open(self.foodname, 'r') as file:
                        reader = csv.DictReader(file)
                        data = list(reader)

                    
                    data = [row for row in data if row['food'] != food_name]

                    
                    with open(self.foodname, 'w', newline='') as file:
                        fieldnames = reader.fieldnames
                        writer = csv.DictWriter(file, fieldnames=fieldnames)
                        writer.writeheader()
                        writer.writerows(data)

                else:
                    print(f"Food widget with identifier {identifier} not found.")
        
    def update_column( self,row_index, new_value):
        
        with open(self.foodname, 'r') as file:
            reader = csv.DictReader(file)
            data = list(reader)

        
        data[row_index]['servings'] = new_value

        
        with open(self.foodname, 'w', newline='') as file:
            fieldnames = reader.fieldnames
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(data)
    def adjust_servings(self, identifier, amount):
        if identifier in self.food_widgets:
            food_widget = self.food_widgets[identifier]['serving_value']
            try:
                current_servings = int(food_widget.cget("text"))
                new_servings = max(0, current_servings + amount)
                food_widget.configure(text=str(new_servings))

                # Update the servings in self.food_data
                food_name = self.food_widgets[identifier]['food_label'].cget("text")
                self.food_data[food_name][1] = new_servings
                
                self.update_total_calories()
                self.update_column(identifier, new_servings)

                print(f"Food name: {food_name}")
                print(f"Previous servings: {self.food_data[food_name][1]}")
                print(f"New servings: {new_servings}")
            except ValueError:
                print('problem')


    def update_total_calories(self):
        self.total_calories = sum(
            int(food_widget['serving_value'].cget("text")) * calories_servings[0] for food_widget, calories_servings in
            zip(self.food_widgets.values(), self.food_data.values())
        )
        self.total_calories_label.configure(text=f'Total Calories: {self.total_calories}')


# if __name__ == "__main__":
#     root = CalorieCounterApp()
#     root.mainloop()

