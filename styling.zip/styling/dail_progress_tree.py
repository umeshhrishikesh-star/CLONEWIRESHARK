import customtkinter as ctk
import tkinter as tk
from tkinter import ttk
import pandas as pd

class DailyWindow(ctk.CTkToplevel):
    def __init__(self ,parent , csv_file):
        super().__init__(parent)
        self.parent = parent
        # self.parent.withdraw()
        self.grab_set()
        
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure("Treeview", background="#2E2E2E", fieldbackground="#2E2E2E", foreground="white", font=(None, 14))
        self.style.configure("Treeview.Heading", background="#404040", foreground="white", font=(None, 14))
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        # Increase window size
        self.tree = ttk.Treeview(self, columns=("Day", "Sleep", "Calories"), show="headings")

        
        # csv_file = r'C:\Users\Hrishikesh U\OneDrive\Documents\test\dailyprgoress.csv'
        df = pd.read_csv(csv_file)
        first_row = list(df.columns)

        for col in first_row:
            self.tree.heading(col, text=col, anchor="center", command=lambda c=col: self.sort_column(c))

        
        for index, row in df.iloc[1:].iterrows():
            self.tree.insert('', index, values=row.tolist())

        self.tree.pack(expand=True, fill='both')

    def sort_column(self, col):
        data = [(self.tree.set(child, col), child) for child in self.tree.get_children('')]
        data.sort(reverse=False)
        for i, item in enumerate(data):
            self.tree.move(item[1], '', i)
    def on_close(self):
        # self.parent.deiconify()
        self.destroy()

# a = DailyWindow('hi')
# a.mainloop()
